    function getDetails() {

    var x = document.getElementById("frm1");
    var name = "" ;
    name += x.elements[0].value;
    if(name.trim()==""){
        document.getElementById("reqError").innerHTML="* Name is required.";
        return false;
    }
    document.getElementById("reqError").innerHTML="";
    document.getElementById("demo").innerHTML = name;
    var xhttp = new XMLHttpRequest();
    //xhttp.open("GET", "https://restcountries.eu/rest/v2/name/"+name);

    xhttp.open("GET", "https://restcountries.eu/rest/v2/name/"+name+"?fullText=true");
    xhttp.send();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var myArr = JSON.parse(this.responseText);
 
           for (i = 0; i < myArr.length; i++) {
                Countryname = myArr[i].name;
                var compare =  'name'.localeCompare('Countryname', undefined, { sensitivity: 'base' }); 
                if(compare){
                    capital = myArr[i].capital + "<br>";
                    region = myArr[i].region ;
                    
                    document.getElementById("demo").innerHTML = " * Capital of provided Country is : " +capital;
                    document.getElementById("region").innerHTML = " * Region of provided Country is:  " +region;
                    
                    }
                }
            }
                 else{
                     document.getElementById("demo").innerHTML = "Ugh! You entered a invalid country name OR Given REST API WebSrevice is not available for the provided country.Try again with valid country name.Thanks! ";
                     document.getElementById("region").innerHTML = "";
                   
                     }
                    document.getElementById('showdiv').style.display = 'block';      
                };
    }

    function show()
        {
       document.getElementById('CountryName').value = "";
       document.getElementById("demo").innerHTML = "";
       document.getElementById("region").innerHTML = "";
       }

    function hide()
       {
       window.location.href = "thanks.html";
       }
